<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'praksa_php' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'abcBFm^-+HXBA*EI(=8KA!m}9WER[/B-sAtjP*1Q It+H8fW@b#OKu8>dZ=0xsL=' );
define( 'SECURE_AUTH_KEY',  'ZO<8#E_cLQtGG,P]g+>=0 6AGaRW%E]`mad.VR@{)#x?6,:_ZKcK/#4Dy>BGf. A' );
define( 'LOGGED_IN_KEY',    'cnnlz$e8&ah_])TrTbM)6p!>QbH-!~6H?zSHFr=@]qutWMinD5@DAul-;z0F:6IO' );
define( 'NONCE_KEY',        '*:dN8E1(?[&8Ox1qC7_aw27?Sor,7[4k`k*N0`3c6^hFbIMIiR2UIDfQ6<{_w+/S' );
define( 'AUTH_SALT',        '=1HSYs<s9wx]p<D3;4^[mL5,$zR<7/~j$Q/jf=@R:R%RwjtvK45++riFPx9 J)<r' );
define( 'SECURE_AUTH_SALT', 'Ne9sWjW99K3lK_5Mm~F7@(;K8mTzgRhhuApiarX ,7*010<13Dc`)6=*w{i9+; f' );
define( 'LOGGED_IN_SALT',   'aXwANt|r/t(t?Xo&R`]-6Xj:X.Xm@Q}n_9a]NkQ6BvETGA#BJCCK_C:#L ap#x${' );
define( 'NONCE_SALT',       'n2B:`S@!u/qgnlg8T90@1=c(i.Fb5WN)iq%MvJAd9h+qqu;1!@754P(JMZ<L$}E<' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
